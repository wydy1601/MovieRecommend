import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import scala.collection.Map
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.mllib.recommendation._
import org.apache.spark.rdd.RDD
import org.apache.spark.mllib.recommendation.MatrixFactorizationModel
import java.sql.{Connection, DriverManager}
import java.net.URI
import scala.collection.mutable.ArrayBuffer

case class MovieRating(userID: String, movieID: Int, rating: Double, timestamp: Long) extends scala.Serializable

object MovieRecommend {
  val mysqlConf = Map(

    "driver" -> "com.mysql.cj.jdbc.Driver",

    "url" -> "jdbc:mysql://localhost:3306/movierecommend",

    "username" -> "root",

    "password" -> "hadoop"

  )

  def getMysqlConn():Connection = {
    Class.forName(mysqlConf("driver"))

    DriverManager.getConnection(mysqlConf("url"),mysqlConf("username"),mysqlConf("password"))

  }

  def main(args: Array[String]): Unit = {
    val sc = new SparkContext(new SparkConf().setAppName("MovieRecommend").setMaster("local"))
    sc.setLogLevel("ERROR")
    val base = if (args.length > 0) args(0) else "hdfs://localhost:9000/user/hadoop/input/"

    //获取RDD
    val rawUserMoviesData = sc.textFile(base + "ratings.dat")
    val rawHotMoviesData = sc.textFile(base + "movies.dat")

    //准备数据
    preparation(rawUserMoviesData, rawHotMoviesData)
    println("准备完数据")

    model(sc, rawUserMoviesData, rawHotMoviesData, base)

    //recommend(sc, rawUserMoviesData, rawHotMoviesData,base)
  }

  //得到电影名字的RDD
  def buildMovies(rawHotMoviesData: RDD[String]): Map[Int, String] =
    rawHotMoviesData.flatMap { line =>
      val tokens = line.split("::")
      if (tokens(0).isEmpty) {
        None
      } else {
        Some((tokens(0).toInt, tokens(1)))
      }
    }.collectAsMap()

  def parseRating(str: String): MovieRating = {
    val fields = str.split("::")
    assert(fields.size == 4)
    MovieRating(fields(0), fields(1).toInt, fields(2).toFloat,fields(3).toLong)
  }


  //分析清理数据
  def preparation( rawUserMoviesData: RDD[String], rawHotMoviesData: RDD[String]) = {
    val userIDStats = rawUserMoviesData.map(_.split("::")(0).trim).distinct().zipWithUniqueId().map(_._2.toDouble).stats()
    val itemIDStats = rawUserMoviesData.map(_.split("::")(1).trim.toDouble).distinct().stats()

    val moviesAndName = buildMovies(rawHotMoviesData)

    val (movieID, movieName) = moviesAndName.head
  }

  //
  def buildRatings(rawUserMoviesData: RDD[String]): RDD[MovieRating] = {
    rawUserMoviesData.map { line =>
      val Array(userIDStr, moviesIDStr, ratingStr, timestampStr) = line.split("::").map(_.trim)
      var rating = ratingStr.toDouble
      var moviesID = moviesIDStr.toInt
      var timestamp = timestampStr.toLong
      MovieRating(userIDStr, moviesID.toInt, rating, timestamp)
    }
  }


  def model(sc: SparkContext, rawUserMoviesData: RDD[String], rawHotMoviesData: RDD[String], base:String): Unit = {

    val moviesAndName = buildMovies(rawHotMoviesData)
    val bMoviesAndName = sc.broadcast(moviesAndName)

    val data = buildRatings(rawUserMoviesData)

    val userIdToInt: RDD[(String, Long)] = data.map(_.userID).distinct().zipWithUniqueId()
    val reverseUserIDMapping: RDD[(Long, String)] = userIdToInt map { case (l, r) => (r, l) }

    val userIDMap: Map[String, Int] =
      userIdToInt.collectAsMap().map { case (n, l) => (n, l.toInt) }

    val bUserIDMap = sc.broadcast(userIDMap)

    val ratings: RDD[Rating] = data.map { r =>
      Rating(bUserIDMap.value(r.userID), r.movieID, r.rating)
    }.cache()

    val putPath = new Path(base+"model")
    val conf = new Configuration()
    val hdfs = FileSystem.newInstance(URI.create(base+"model"),conf)

    if (hdfs.exists(putPath)){
      val model = MatrixFactorizationModel.load(sc, base+"model")

      ratings.unpersist()

      checkRecommenderResult(1, rawUserMoviesData, bMoviesAndName, reverseUserIDMapping, model)

      unpersist(model)
    }
    else{
      val model = ALS.train(ratings, 50, 10, 0.0001)
      model.save(sc, base+"model")

      ratings.unpersist()

      checkRecommenderResult(1, rawUserMoviesData, bMoviesAndName, reverseUserIDMapping, model)

      unpersist(model)
    }

  }

  //
  //查看给某个用户的推荐
  def checkRecommenderResult(userID: Int, rawUserMoviesData: RDD[String], bMoviesAndName: Broadcast[Map[Int, String]], reverseUserIDMapping: RDD[(Long, String)], model: MatrixFactorizationModel): Unit = {
    val userName = reverseUserIDMapping.lookup(userID).head

    val recommendations = model.recommendProducts(userID, 5)
    //给此用户的推荐的电影ID集合
    val recommendedMovieIDs = recommendations.map(_.product).toSet

    val conn = getMysqlConn()
    try{
      val statement = conn.createStatement()
      val clear = "truncate recommendresult"
      val count = statement.executeUpdate(clear)

      val recommended_Ids = bMoviesAndName.value.filter { case (id, name) => recommendedMovieIDs.contains(id) }.keys.toArray
      val recommended_Names = bMoviesAndName.value.filter { case (id, name) => recommendedMovieIDs.contains(id) }.values.toArray

      for(i <- 0 to recommended_Ids.length-1){
        val sql_insert = "insert into recommendresult value(" + String.valueOf(userID) + ", " + String.valueOf(recommended_Ids(i)) + ", " + "0" + ", " + "'" + String.valueOf(recommended_Names(i)) + "'" + ")"
        println(sql_insert)
        val count = statement.executeUpdate(sql_insert)
      }

    }catch {
      case e : Throwable => e.printStackTrace()

    }finally {
      conn.close()

    }

    println("推荐给用户" + userName + "的电影名")
    //推荐的电影名
    bMoviesAndName.value.filter { case (id, name) => recommendedMovieIDs.contains(id) }.values.foreach(println)

  }


  def recommend(sc: SparkContext,
                rawUserMoviesData: RDD[String],
                rawHotMoviesData: RDD[String],
                base:String): Unit = {
    val moviesAndName = buildMovies(rawHotMoviesData)
    val bMoviesAndName = sc.broadcast(moviesAndName)

    val data = buildRatings(rawUserMoviesData)

    val userIdToInt: RDD[(String, Long)] =
      data.map(_.userID).distinct().zipWithUniqueId()
    val reverseUserIDMapping: RDD[(Long, String)] =
      userIdToInt map { case (l, r) => (r, l) }

    val userIDMap: Map[String, Int] =
      userIdToInt.collectAsMap().map { case (n, l) => (n, l.toInt) }

    val bUserIDMap = sc.broadcast(userIDMap)
    val bReverseUserIDMap = sc.broadcast(reverseUserIDMapping.collectAsMap())

    val ratings: RDD[Rating] = data.map { r =>
      Rating(bUserIDMap.value.get(r.userID).get, r.movieID, r.rating)
    }.cache()
    //使用协同过滤算法建模
    val model = MatrixFactorizationModel.load(sc, base+"model")
    ratings.unpersist()

    val allRecommendations = model.recommendProductsForUsers(5) map {
      case (userID, recommendations) => {
        var recommendationStr = ""
        for (r <- recommendations) {
          recommendationStr += r.product + ":" + bMoviesAndName.value.getOrElse(r.product, "") + ","
        }
        if (recommendationStr.endsWith(","))
          recommendationStr = recommendationStr.substring(0,recommendationStr.length-1)

        (bReverseUserIDMap.value.get(userID).get,recommendationStr)
      }
    }

    //allRecommendations.saveAsTextFile(base + "result.csv")
    allRecommendations.coalesce(1).sortByKey().saveAsTextFile(base + "result.csv")

    unpersist(model)
  }

  def unpersist(model: MatrixFactorizationModel): Unit = {
    model.userFeatures.unpersist()
    model.productFeatures.unpersist()
  }

}